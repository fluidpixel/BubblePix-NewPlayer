Shape - A closed 2d path with holes
----------------------------------------

.. rubric:: Constructor

.. class:: Shape()

    A closed 2d Path with holes
    
.. rubric:: Attributes

.. rubric:: Method

.. rubric:: Example(s)
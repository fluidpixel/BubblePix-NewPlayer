Path - A CurvePath with a Drawing API
-------------------------------------------

.. rubric:: Constructor

.. class:: Path()

    A CurvePath with convenience Drawing methods 
    
.. rubric:: Attributes

.. rubric:: Method

.. rubric:: Example(s)
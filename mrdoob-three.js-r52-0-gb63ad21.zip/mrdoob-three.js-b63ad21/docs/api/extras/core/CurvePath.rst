CurvePath - Path with connected curves
-------------------------------------------

.. rubric:: Constructor

.. class:: CurvePath()

    A Path made with connected set of curves
    
.. rubric:: Attributes

.. rubric:: Method

.. rubric:: Example(s)
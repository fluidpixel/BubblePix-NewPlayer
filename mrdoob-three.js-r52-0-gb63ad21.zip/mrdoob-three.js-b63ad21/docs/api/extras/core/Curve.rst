Curve - Extensible curve object
--------------------------------------

.. rubric:: Constructor

.. class:: Curve()

    Extensible curve object

.. rubric:: Attributes

.. rubric:: Method

.. rubric:: Example(s)
    
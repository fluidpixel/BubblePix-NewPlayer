Model from http://www.3drt.com/downloads.htm
